import java.lang.*;

public class Main
{
	public static void main(String[] args)
	{
	    new Login();
		//new Registration();
		//new Home();
	}
}