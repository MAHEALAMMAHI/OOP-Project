import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

class UserFileManager {
    private String filePath;

    public UserFileManager(String filePath) {
        this.filePath = filePath;
    }

    public void saveUser(User user) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true));
        writer.write(user.getUserData());
        writer.newLine();
        writer.close();
    }
}











