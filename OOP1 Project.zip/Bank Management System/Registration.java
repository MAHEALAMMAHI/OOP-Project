import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.IOException;

public class Registration {
    private JFrame f1;
    private JLabel l1, l2, l3, l4, l5;
    private JButton b1, b2, b3;
    private JTextField t1, t2;
    private JPasswordField p1, p2;

    private UserFileManager userFileManager; 

    public Registration() {
        f1 = new JFrame("Register Here");
        l1 = new JLabel("Create Your Account");
        l2 = new JLabel("Name ");
        l3 = new JLabel("Email");
        l4 = new JLabel("Password");
        l5 = new JLabel("Confirm Password");
        b1 = new JButton("Register");
        b2 = new JButton("Clear");
        b3 = new JButton("Back");
        t1 = new JTextField();
        t2 = new JTextField();
        p1 = new JPasswordField();
        p2 = new JPasswordField();
		
		
        userFileManager = new UserFileManager("registration_data.txt");

        f1.setSize(500, 600);
        f1.setLayout(null);
        f1.setVisible(true);
        f1.setResizable(false);

        l1.setBounds(120, 50, 500, 40);
        l2.setBounds(100, 130, 500, 40);
        l3.setBounds(100, 200, 500, 40);
        l4.setBounds(100, 270, 500, 40);
        l5.setBounds(100, 340, 500, 40);
        b1.setBounds(100, 450, 120, 30);
        b2.setBounds(230, 450, 120, 30);
        b3.setBounds(400, 20, 70, 30);
        t1.setBounds(100, 170, 250, 30);
        t2.setBounds(100, 240, 250, 30);
        p1.setBounds(100, 310, 250, 30);
        p2.setBounds(100, 380, 250, 30);
		
		l1.setFont(new Font("Arial",Font.BOLD,20));

       
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String name = t1.getText();
                String email = t2.getText();
                String password = new String(p1.getPassword());
                String confirmPassword = new String(p2.getPassword());

                if (name.isEmpty() || email.isEmpty()|| password.isEmpty()|| confirmPassword.isEmpty()) {
                    JOptionPane.showMessageDialog(f1, "Fields can not be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
				else{
					if (!password.equals(confirmPassword)) {
                    JOptionPane.showMessageDialog(f1, "Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
				else{
					User user = new User(name, email, password);

                try {
                    userFileManager.saveUser(user);
                    JOptionPane.showMessageDialog(f1, "Registration Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    f1.setVisible(false);
                    new Login();
                } catch (IOException ioe) {
                    JOptionPane.showMessageDialog(f1, "Error saving data!", "Error", JOptionPane.ERROR_MESSAGE);
                    
                }
					
				}

                
					
				}
                
            }
        });

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                t1.setText("");
                t2.setText("");
                p1.setText("");
                p2.setText("");
            }
        });

        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                f1.setVisible(false);
                new Login();
            }
        });

        f1.add(l1);
        f1.add(l2);
        f1.add(l3);
        f1.add(l4);
        f1.add(l5);
        f1.add(b1);
        f1.add(b2);
        f1.add(b3);
        f1.add(t1);
        f1.add(t2);
        f1.add(p1);
        f1.add(p2);
	
        ImageIcon bk = new ImageIcon("reg.png");
        Image img = bk.getImage();
        Image tmpImg = img.getScaledInstance(500, 600, Image.SCALE_SMOOTH);
        bk = new ImageIcon(tmpImg);
        JLabel pic = new JLabel("", bk, JLabel.CENTER);
        pic.setBounds(0, 0, 500, 600);
        f1.add(pic);
    }

    public static void main(String[] args) {
        new Registration();
    }
}
