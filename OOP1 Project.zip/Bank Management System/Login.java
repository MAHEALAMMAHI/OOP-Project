import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.awt.event.*;

public class Login {
    private JFrame f;
    private JLabel l1, l2, l3, l4;
    private JButton b1, b2;
    private JTextField t1;
    private JPasswordField p1;

    public Login() {
        f = new JFrame("AIUB");
        b1 = new JButton("Log In");
        b2 = new JButton("Register");
        l1 = new JLabel("Welcome To Bank of AIUB");
        l2 = new JLabel("User         :");
        l3 = new JLabel("Password :");
        l4 = new JLabel("Can't Access Your Account?");
        t1 = new JTextField();
        p1 = new JPasswordField();

        f.setSize(500, 400);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(true);

        b1.setBounds(200, 250, 70, 30);
        b2.setBounds(280, 250, 100, 30);
        l1.setBounds(150, 60, 500, 40);
        l2.setBounds(150, 130, 120, 30);
        l3.setBounds(150, 180, 120, 30);
        l4.setBounds(200, 300, 200, 30);
        t1.setBounds(220, 130, 170, 30);
        p1.setBounds(220, 180, 170, 30);
		
		
		l1.setFont(new Font("Arial",Font.BOLD,20));

        
        ImageIcon bk = new ImageIcon("log.jpg");
        Image img = bk.getImage();
        Image tmpImg = img.getScaledInstance(500, 400, Image.SCALE_SMOOTH);
        bk = new ImageIcon(tmpImg);
        JLabel l5 = new JLabel("", bk, JLabel.CENTER);
        l5.setBounds(0, 0, 500, 400);
        f.add(l5);

        
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String username = t1.getText().trim();
                String password = new String(p1.getPassword()).trim();

                
                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(f, "Username and password cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                
                if (isValidLogin(username, password)) {
                    JOptionPane.showMessageDialog(f, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    f.setVisible(false);
                     new Home(); 
                } else {
                    JOptionPane.showMessageDialog(f, "Invalid Username or Password!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                f.setVisible(false);
                new Registration();
            }
        });

        f.add(b1);
        f.add(b2);
        f.add(l1);
        f.add(l2);
        f.add(l3);
        f.add(l4);
        f.add(t1);
        f.add(p1);
        f.add(l5);
    }

    
    private boolean isValidLogin(String username, String password) {
        String filePath = "registration_data.txt";
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data.length > 1 && data[1].equals(username) && data[2].equals(password)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void main(String[] args) {
        new Login();
    }
}
