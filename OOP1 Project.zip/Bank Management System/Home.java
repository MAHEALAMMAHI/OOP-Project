import java.lang.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Home {
    private JFrame f;
    private JButton b1, b2, b3, b4, b5;
    private Usr usr; 

    public Home() {
        
        usr = new Usr();

        f = new JFrame("Dashboard");
        b1 = new JButton("Logout");
        b2 = new JButton("Check Balance");
        b3 = new JButton("Deposit");
        b4 = new JButton("Withdraw");
        b5 = new JButton("Update Profile");

        JLabel title = new JLabel("Welcome To The Bank");
        title.setBounds(100, 30, 250, 30);
		title.setFont(new Font("Arial",Font.BOLD,20));
        

        f.setSize(500, 400);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setResizable(false);

        b1.setBounds(330, 300, 100, 30);
        b2.setBounds(185, 260, 120, 30);
        b3.setBounds(110, 135, 100, 30);
        b4.setBounds(305, 135, 100, 30);
        b5.setBounds(50, 300, 120, 30);
		
		
        b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
            f.setVisible(false);
            new Login(); 
			}
        });

        
        b2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
            JOptionPane.showMessageDialog(f, "Your balance: $" + usr.getBalance());
			} });

        
        b3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
            String input = JOptionPane.showInputDialog("Enter amount to deposit:");
            try {
                double amount = Double.parseDouble(input);
                usr.deposit(amount);
                JOptionPane.showMessageDialog(f, "Amount deposited successfully!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(f, "Invalid input. Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(f, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
			}
        });

        
        b4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
            String input = JOptionPane.showInputDialog("Enter amount to withdraw:");
            try {
                double amount = Double.parseDouble(input);
                usr.withdraw(amount);
                JOptionPane.showMessageDialog(f, "Amount withdrawn successfully!");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(f, "Invalid input. Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(f, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
			}
        });

        
        b5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae){
            JOptionPane.showMessageDialog(f, "Profile update feature is coming soon!");
			}});

        
        f.add(b1);
        f.add(b2);
        f.add(b3);
        f.add(b4);
        f.add(b5);
		f.add(title);
		
        ImageIcon bk = new ImageIcon("home.png");
        Image img = bk.getImage();
        Image tmpImg = img.getScaledInstance(500, 400, Image.SCALE_SMOOTH);
        bk = new ImageIcon(tmpImg);
        JLabel pic = new JLabel("", bk, JLabel.CENTER);
        pic.setBounds(0, 0, 500, 400);
        f.add(pic);
    }

    public static void main(String[] args) {
        new Home();
    }
}


class Usr {
    private double balance;

    public Usr() {
        this.balance = 0.0; 
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
        } else {
			
            throw new IllegalArgumentException("Deposit amount must be positive");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
        } else {
            throw new IllegalArgumentException("Invalid withdraw amount");
        }
    }
}











